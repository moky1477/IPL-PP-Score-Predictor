1. The sample input file is not a (real) match data.
2. If the player is new to the tournament, then the player name will be similar to the official website.
3. The original input file for each match will be updated after the end of the match.
